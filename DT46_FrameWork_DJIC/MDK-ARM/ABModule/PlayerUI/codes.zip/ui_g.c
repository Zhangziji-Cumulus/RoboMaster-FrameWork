//
// Created by RM UI Designer
// Static Edition
//

#include <string.h>

#include "ui_interface.h"

ui_1_frame_t ui_g_Ungroup_0;

ui_interface_round_t *ui_g_Ungroup_lest = (ui_interface_round_t*)&(ui_g_Ungroup_0.data[0]);

void _ui_init_g_Ungroup_0() {
    for (int i = 0; i < 1; i++) {
        ui_g_Ungroup_0.data[i].figure_name[0] = 0;
        ui_g_Ungroup_0.data[i].figure_name[1] = 0;
        ui_g_Ungroup_0.data[i].figure_name[2] = i + 0;
        ui_g_Ungroup_0.data[i].operate_type = 1;
    }
    for (int i = 1; i < 1; i++) {
        ui_g_Ungroup_0.data[i].operate_type = 0;
    }

    ui_g_Ungroup_lest->figure_type = 2;
    ui_g_Ungroup_lest->operate_type = 1;
    ui_g_Ungroup_lest->layer = 0;
    ui_g_Ungroup_lest->color = 0;
    ui_g_Ungroup_lest->start_x = 955;
    ui_g_Ungroup_lest->start_y = 415;
    ui_g_Ungroup_lest->width = 10;
    ui_g_Ungroup_lest->r = 86;


    ui_proc_1_frame(&ui_g_Ungroup_0);
    SEND_MESSAGE((uint8_t *) &ui_g_Ungroup_0, sizeof(ui_g_Ungroup_0));
}

void _ui_update_g_Ungroup_0() {
    for (int i = 0; i < 1; i++) {
        ui_g_Ungroup_0.data[i].operate_type = 2;
    }

    ui_proc_1_frame(&ui_g_Ungroup_0);
    SEND_MESSAGE((uint8_t *) &ui_g_Ungroup_0, sizeof(ui_g_Ungroup_0));
}

void _ui_remove_g_Ungroup_0() {
    for (int i = 0; i < 1; i++) {
        ui_g_Ungroup_0.data[i].operate_type = 3;
    }

    ui_proc_1_frame(&ui_g_Ungroup_0);
    SEND_MESSAGE((uint8_t *) &ui_g_Ungroup_0, sizeof(ui_g_Ungroup_0));
}


void ui_init_g_Ungroup() {
    _ui_init_g_Ungroup_0();
}

void ui_update_g_Ungroup() {
    _ui_update_g_Ungroup_0();
}

void ui_remove_g_Ungroup() {
    _ui_remove_g_Ungroup_0();
}

